#include <stdio.h>

main () 
{
    int var1;
    var1 = 9;
    if ((var1 % 2) != 0) {
        printf("Texto",var1,"La variable no es par.");
        var1=0;
    }
    puts("");
    printf("Texto",var1);
    
//    system ("pause") ;
}

//@ (main)
