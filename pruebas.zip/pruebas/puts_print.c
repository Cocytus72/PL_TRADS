#include <stdio.h>

main () 
{
    int var1;
    var1 = 2;
    printf("Este texto no se imprime", var1,"Este texto si se imprime",var1+4);
    puts("Esto es un puts");
    
//    system ("pause") ;
}

//@ (main)
